package com.Ait.Service;

import java.util.List;
import com.Ait.Dao.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.Ait.Model.Student;

@Service
public class StudentServiceDaoImp implements StudentServiceDao{
		
	@Autowired
	private StudentDao sdao;

	@Override
	public boolean addStudent(Student s) {
		sdao.addStudent(s);
		return true;
	}

	@Override
	public boolean updateStudent(Student s) {
		sdao.updateStudent(s);
		return true;
	}

	@Override
	public List<Student> getAllStudent() {
		return sdao.getAllStudent();
	}

	@Override
	public Student getStudentById(int id) {
		// TODO Auto-generated method stub
		return sdao.getStudentById(id);
	}

	@Override
	public boolean deleteStudent(Student s) {
		// TODO Auto-generated method stub
		return sdao.deleteStudent(s);
	}

}
