package com.Ait.Dao;

import java.util.List;


import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Ait.Model.Student;

@Repository
@Transactional
public class StudentDaoImplementations implements StudentDao {
	
	@Autowired
	private SessionFactory sessionfactory;

	@Override
	public boolean addStudent(Student s) {
		// TODO Auto-generated method stub
		sessionfactory.getCurrentSession().saveOrUpdate(s);
		return true;
	}

	@Override
	public boolean updateStudent(Student s) {
		
		sessionfactory.getCurrentSession().saveOrUpdate(s);
		return true;
	}

	@Override
	public List<Student> getAllStudent() {
	Query<Student>q=sessionfactory.getCurrentSession().createQuery("from Student");
		List<Student>li=q.list();
		return li;
	}
	@Override
	public Student getStudentById(int id) {
		// TODO Auto-generated method stub
		return sessionfactory.getCurrentSession().get(Student.class,id);
	}

	@Override
	public boolean deleteStudent(Student s) {
		
		sessionfactory.getCurrentSession().delete(s);
		return true;
	}
	
	

}
