package com.Ait.Dao;

import java.util.List;

import com.Ait.Model.Student;

public interface StudentDao {
		boolean addStudent(Student s);
		boolean deleteStudent(Student s);
		boolean updateStudent(Student s);
		List<Student>getAllStudent();
		Student getStudentById(int id);
	}

