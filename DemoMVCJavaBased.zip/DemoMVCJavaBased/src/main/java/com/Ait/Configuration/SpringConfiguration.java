package com.Ait.Configuration;


import java.util.Properties;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;



@EnableTransactionManagement
@EnableWebMvc
@ComponentScan("com.Ait")
@Configuration
@PropertySource("classpath:Application.properties")
public class SpringConfiguration {
	
	@Autowired
	private Environment env;
	@Bean
	public InternalResourceViewResolver m1() 
	{
		InternalResourceViewResolver i=new InternalResourceViewResolver();
		i.setPrefix("WEB-INF/JSP/");
		i.setSuffix(".jsp");
		return i;
	}
	
	@Bean
	public LocalSessionFactoryBean sessionFactory() 
	{
		LocalSessionFactoryBean sessionfactory=new LocalSessionFactoryBean();
		sessionfactory.setDataSource(dataSource());
		sessionfactory.setHibernateProperties(hibernateProperties());
		sessionfactory.setPackagesToScan("com.Ait.Model");
		return sessionfactory;
	}
	
	
	public Properties hibernateProperties() 
	{
		Properties p1=new Properties();
		p1.put("hibernate.dialect",env.getRequiredProperty("hibernate.dialect"));
		p1.put("hibernate-hbm2ddl-auto",env.getRequiredProperty("hibernate.hbm2ddl.auto"));
		p1.put("hibernate.show_sql",env.getRequiredProperty("hibernate.show_sql"));
		return p1;
	}
	
	
	public DriverManagerDataSource dataSource() 
	{
		DriverManagerDataSource drivermanager=new DriverManagerDataSource();
		drivermanager.setDriverClassName(env.getRequiredProperty("jdbc.drivername"));
		drivermanager.setUrl(env.getRequiredProperty("jdbc.url"));  //we can directly pass url and driver class name like this
		drivermanager.setUsername(env.getRequiredProperty("jdbc.username"));
		drivermanager.setPassword(env.getRequiredProperty("jdbc.password"));
		return drivermanager;
	}
	
	@Bean
	public HibernateTransactionManager transacionManager(SessionFactory ob) 
	{
		HibernateTransactionManager manager=new HibernateTransactionManager();
		manager.setSessionFactory(ob);
		return manager;
	}
}
