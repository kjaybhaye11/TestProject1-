package com.Ait.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.Ait.Model.Student;
import com.Ait.Service.StudentServiceDao;


@Controller
public class StudentController {
	
	@Autowired
	private StudentServiceDao serv;
	
	@GetMapping("/")
	public ModelAndView displayPage() 
	{
		ModelAndView mv=new ModelAndView("view");
		List<Student>studlist=serv.getAllStudent();
		mv.addObject("studlist", studlist);
		return mv;
	}
	
	@GetMapping("/Delete")
	public String deleteStudent(@RequestParam("id") int id) 
	{
		Student s1=serv.getStudentById(id);
		if(s1!=null) 
			serv.deleteStudent(s1);
		return "redirect:/";
		
	}
	
	@GetMapping("/Add")
	public String addStudent() 
	{
		return "add";
	}
	
	@GetMapping("/save")
	public String saveStudent(@ModelAttribute("stud") Student s1,BindingResult res) throws Exception
	{	
		if(res.hasErrors())
			throw new Exception("Please enter a valid details");
		serv.addStudent(s1);
		return "redirect:/";
	}
	
	@GetMapping("/Edit")
	public ModelAndView updateStudent(@RequestParam("id") int id) 
	{	
		Student s2=serv.getStudentById(id);
		ModelAndView mv=new ModelAndView("edit");
		mv.addObject("std", s2);
		return mv;
	}
	
	@ExceptionHandler(value = Exception.class)
	public String someException() 
	{
		return "error";
	}
	
	@GetMapping("/update")
	public String updateStudent(@ModelAttribute("stu") Student s1) 
	{	
		serv.updateStudent(s1);
		return "redirect:/";
	}
	
}
