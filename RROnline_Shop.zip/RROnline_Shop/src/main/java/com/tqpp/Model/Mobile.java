package com.tqpp.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Mobile {

	
	@Id
	@GeneratedValue
	private int mid;
	private String brand;
	private int price;
	private int storage;
	private String colour;
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getStorage() {
		return storage;
	}
	public void setStorage(int storage) {
		this.storage = storage;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public Mobile(int mid, String brand, int price, int storage, String colour) {
		super();
		this.mid = mid;
		this.brand = brand;
		this.price = price;
		this.storage = storage;
		this.colour = colour;
	}
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Mobile [mid=" + mid + ", brand=" + brand + ", price=" + price + ", storage=" + storage + ", colour="
				+ colour + "]";
	}
	
	
}
