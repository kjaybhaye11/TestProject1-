package com.tqpp.Dao;

public class RoleDao {

}
