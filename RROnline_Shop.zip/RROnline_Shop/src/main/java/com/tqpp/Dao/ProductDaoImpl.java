package com.tqpp.Dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tqpp.Model.Product;


@Transactional
@Repository
public class ProductDaoImpl implements ProductDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public boolean addProduct(Product s) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(s);
		return true;
	}

	@Override
	public boolean deleteProduct(Product s) {
		// TODO Auto-generated method stub

		sessionFactory.getCurrentSession().delete(s);
		return true;
	}

	@Override
	public boolean updateProduct(Product s) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().saveOrUpdate(s);
		return true;
	}

	@Override
	public List<Product> getAllProducts() {
		Query<Product> q=sessionFactory.getCurrentSession().createQuery("from Product");
		List<Product> productlist=q.list();
		return productlist;
	}

	@Override
	public Product getProductById(int id) {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().get(Product.class, id);
	}

	

}
